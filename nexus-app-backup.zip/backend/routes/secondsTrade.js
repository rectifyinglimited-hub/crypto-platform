/**
 * =============================================================================
 *  NEXUS BACKEND — routes/secondsTrade.js
 * =============================================================================
 *  Fixed-time trading:
 *    POST   /open
 *    GET    /active
 *    GET    /history
 *    POST   /settle/:id
 *    GET    /markets          — reference live prices (proxy + bias, auth)
 *    GET    /public-markets   — unbiased Binance spot prices (public landing)
 * =============================================================================
 */

import { Router } from "express";
import { body, param, validationResult } from "express-validator";
import mongoose from "mongoose";

import User from "../models/User.js";
import SecondsTrade from "../models/SecondsTrade.js";
import Transaction from "../models/Transaction.js";
import PlatformConfig from "../models/PlatformConfig.js";
import { requireAuth } from "../middleware/auth.js";
import { signedBiasForOutcome } from "../lib/tradeBias.js";
import {
  resolveAlgoOutcome,
  rollWinPercentage,
  defaultAlgoMatrix,
} from "../lib/tradeAlgo.js";
import { emitChartResync, emitWalletUpdate, emitTradeOpened, emitTradeSettled } from "../socket.js";
import { onTradeSettled } from "../lib/referralEngine.js";
import {
  CRYPTO_ASSETS_UNIQUE as CRYPTO_ASSETS,
  STOCK_ASSETS,
  FOREX_ASSETS,
  FALLBACK_PRICES,
  fallbackPrice,
  toExchangeSymbol,
  normalizeQuote,
  resolveAssetType,
} from "../lib/tradeAssets.js";

const router = Router();

const DEFAULT_PAYOUT = 85;
const MIN_DURATION = 10;
const MAX_DURATION = 3600;

/** Cached Binance all-ticker snapshot (refreshed ~1s) */
let binanceTickerCache = { at: 0, map: null };

async function fetchBinanceTickerMap() {
  const now = Date.now();
  if (binanceTickerCache.map && now - binanceTickerCache.at < 900) {
    return binanceTickerCache.map;
  }
  try {
    const ctrl = AbortSignal.timeout(5000);
    const res = await fetch(
      "https://api.binance.com/api/v3/ticker/price",
      { signal: ctrl }
    );
    if (!res.ok) return binanceTickerCache.map;
    const data = await res.json();
    const map = {};
    for (const row of data) {
      const sym = String(row.symbol || "");
      const price = Number(row.price);
      if (!Number.isFinite(price) || price <= 0) continue;
      map[sym] = price;
    }
    binanceTickerCache = { at: now, map };
    return map;
  } catch {
    return binanceTickerCache.map;
  }
}

const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

const sendValidationError = (res, errors) =>
  res.status(422).json({
    success: false,
    error: "ValidationError",
    message: "One or more fields are invalid.",
    details: errors.array().map((e) => ({
      field: e.path || e.param,
      message: e.msg,
    })),
  });

const requireDatabase = (_req, res, next) => {
  if (mongoose.connection.readyState !== 1) {
    return res.status(503).json({
      success: false,
      error: "ServiceUnavailable",
      message: "Database is offline. Trading is temporarily disabled.",
    });
  }
  return next();
};

const walletToObject = (wallet) => {
  if (!wallet) return {};
  if (wallet instanceof Map) return Object.fromEntries(wallet);
  return { ...wallet };
};

/** Public user-facing trade payload — never leak admin control fields */
const serializeTrade = (t, { forAdmin = false } = {}) => {
  const doc = typeof t.toObject === "function" ? t.toObject() : { ...t };
  const now = Date.now();
  const expiresAt = new Date(doc.expiresAt).getTime();
  const remainingSec = Math.max(0, Math.ceil((expiresAt - now) / 1000));

  const base = {
    _id: doc._id,
    asset: doc.asset,
    quote: doc.quote || (doc.assetType === "crypto" ? "USDT" : "USD"),
    assetType: doc.assetType,
    direction: doc.direction,
    stake: doc.stake,
    durationSec: doc.durationSec,
    entryPrice: doc.entryPrice,
    exitPrice: doc.exitPrice,
    status: doc.status,
    payout: doc.payout,
    openedAt: doc.openedAt,
    expiresAt: doc.expiresAt,
    settledAt: doc.settledAt,
    createdAt: doc.createdAt,
    updatedAt: doc.updatedAt,
    remainingSec,
    isExpired: remainingSec <= 0 && doc.status === "open",
  };

  // Settled wins show natural profit % (including admin-forced / graph wins)
  if (doc.status === "won" && doc.payoutPercent != null) {
    base.payoutPercent = doc.payoutPercent;
  }
  // Settled losses: show loss amount only (stake / extra), never admin tags
  if (doc.status === "lost") {
    base.lossAmount = Number(doc.lossAmount || doc.stake || 0);
  }

  if (forAdmin) {
    return {
      ...base,
      user: doc.user,
      forcedOutcome: doc.forcedOutcome,
      forcedAmount: doc.forcedAmount,
      priceBiasPercent: doc.priceBiasPercent,
      payoutPercent: doc.payoutPercent,
      settleReason: doc.settleReason,
      lossAmount: doc.lossAmount,
    };
  }

  return base;
};

function priceDecimals(sym, price) {
  if (price < 0.0001) return 10;
  if (price < 0.01) return 8;
  if (price < 1) return 6;
  if (price < 100) return 4;
  return 2;
}

async function fetchLivePrice(asset, tickerMap, quote = "USDT") {
  const sym = String(asset).toUpperCase();
  const q = normalizeQuote(quote, resolveAssetType(sym) || "crypto");
  const pair = toExchangeSymbol(sym, q);
  if (pair && tickerMap?.[pair] > 0) return tickerMap[pair];
  if (q === "USDC") {
    const usdtPair = toExchangeSymbol(sym, "USDT");
    if (usdtPair && tickerMap?.[usdtPair] > 0) return tickerMap[usdtPair];
  }
  if (!tickerMap && pair && (CRYPTO_ASSETS.includes(sym) || FOREX_ASSETS.includes(sym))) {
    try {
      const ctrl = AbortSignal.timeout(4000);
      const res = await fetch(
        `https://api.binance.com/api/v3/ticker/price?symbol=${pair}`,
        { signal: ctrl }
      );
      if (res.ok) {
        const data = await res.json();
        const price = Number(data.price);
        if (Number.isFinite(price) && price > 0) return price;
      }
    } catch {
      /* fall through */
    }
    if (q === "USDC") {
      try {
        const usdtPair = toExchangeSymbol(sym, "USDT");
        const ctrl = AbortSignal.timeout(4000);
        const res = await fetch(
          `https://api.binance.com/api/v3/ticker/price?symbol=${usdtPair}`,
          { signal: ctrl }
        );
        if (res.ok) {
          const data = await res.json();
          const price = Number(data.price);
          if (Number.isFinite(price) && price > 0) return price;
        }
      } catch {
        /* fall through */
      }
    }
  }
  const base = fallbackPrice(sym);
  const jitter = 1 + (Math.random() - 0.5) * 0.004;
  const p = base * jitter;
  return Number(p.toFixed(priceDecimals(sym, p)));
}

function applyBias(price, biasPercent) {
  const b = Number(biasPercent) || 0;
  return price * (1 + b / 100);
}

/**
 * Settle an expired trade and update Trading Wallet.
 * Stake was deducted on open. Call ONLY when expiresAt <= now.
 *
 * Manual Balance Add (admin Force / Graph lock with forcedAmount):
 *   WIN  → balance += stake + |manual|
 *   LOSS → balance += stake - |manual|   (return remainder of stake)
 * Market / sticky % wins use payoutPercent; plain losses keep stake deducted.
 * Force WIN / LOSS / Graph UP / DOWN only stamp outcome — never settle early.
 */
export async function settleTrade(
  tradeId,
  { exitPriceHint, forceOutcome } = {}
) {
  // Atomic claim — stamp Force WIN/LOSS in the SAME update so a concurrent
  // market settler cannot settle as LOSS before admin force lands.
  // Never clear forcedAmount here — Manual Balance Add must survive until credit.
  const isForce = forceOutcome === "win" || forceOutcome === "loss";
  const claimSet = { status: "settling" };
  if (isForce) {
    claimSet.forcedOutcome = forceOutcome;
  }

  let trade = await SecondsTrade.findOneAndUpdate(
    { _id: tradeId, status: "open" },
    { $set: claimSet },
    { new: true }
  );

  // Reclaim a stuck "settling" trade (crash / timeout mid-settle)
  if (!trade && isForce) {
    trade = await SecondsTrade.findOneAndUpdate(
      {
        _id: tradeId,
        status: "settling",
        settledAt: null,
      },
      { $set: claimSet },
      { new: true }
    );
  }

  if (!trade) {
    // Concurrent settler may still be mid-flight — wait briefly so clients
    // never receive a transient "settling" doc that maps to a false LOSS toast.
    let existing = await SecondsTrade.findById(tradeId);
    if (existing?.status === "settling") {
      await new Promise((r) => setTimeout(r, 400));
      existing = await SecondsTrade.findById(tradeId);
    }
    return existing;
  }

  const user = await User.findById(trade.user);
  if (!user) {
    await SecondsTrade.findByIdAndUpdate(tradeId, { status: "open" });
    return SecondsTrade.findById(tradeId);
  }

  let exitPrice;
  if (exitPriceHint != null && Number.isFinite(Number(exitPriceHint))) {
    exitPrice = Number(exitPriceHint);
  } else if (
    isForce ||
    trade.forcedOutcome === "win" ||
    trade.forcedOutcome === "loss"
  ) {
    exitPrice = Number(trade.entryPrice);
  } else {
    exitPrice = await fetchLivePrice(trade.asset, null, trade.quote || "USDT");
  }
  exitPrice = applyBias(exitPrice, trade.priceBiasPercent);

  // Outcome priority: per-trade forced → user sticky control → market
  let outcome = null;
  let reason = "market";

  if (trade.forcedOutcome === "win" || trade.forcedOutcome === "loss") {
    outcome = trade.forcedOutcome;
    reason = "admin_force";
  } else if (user.tradeControlState === "force_win") {
    outcome = "win";
    reason = "user_force_win";
  } else if (user.tradeControlState === "force_loss") {
    outcome = "loss";
    reason = "user_force_loss";
  } else {
    // Dynamic algorithmic matrix (when global trading ON, no manual force)
    let algoApplied = false;
    try {
      const platform = await PlatformConfig.getSingleton();
      if (platform.globalTradingEnabled !== false) {
        const matrix = {
          ...defaultAlgoMatrix(),
          ...(platform.algoMatrix?.toObject?.() || platform.algoMatrix || {}),
        };
        const cursor =
          user.tradeAlgoCursor?.toObject?.() || user.tradeAlgoCursor || {};
        const resolved = resolveAlgoOutcome({
          stake: trade.stake,
          matrix,
          cursor,
          maxAllIn: !!trade.maxAllIn,
        });
        if (resolved.outcome === "win" || resolved.outcome === "loss") {
          outcome = resolved.outcome;
          reason = resolved.reason;
          algoApplied = true;
          if (resolved.cursorPatch) {
            user.tradeAlgoCursor = resolved.cursorPatch;
            user.markModified("tradeAlgoCursor");
            await user.save();
          }
        } else if (matrix.enabled && Number.isFinite(Number(matrix.winPercentage))) {
          const rolled = rollWinPercentage(matrix.winPercentage);
          if (rolled) {
            outcome = rolled;
            reason = "algo_win_pct";
            algoApplied = true;
          }
        }
      }
    } catch {
      /* fall through to market */
    }

    if (!algoApplied) {
      const rose = exitPrice >= trade.entryPrice;
      const won =
        (trade.direction === "long" && rose) ||
        (trade.direction === "short" && !rose);
      outcome = won ? "win" : "loss";
      reason = "market";
    }
  }

  // Align displayed exit with outcome for chart consistency
  if (outcome === "win") {
    if (trade.direction === "long") {
      exitPrice = Math.max(exitPrice, trade.entryPrice * 1.004);
    } else {
      exitPrice = Math.min(exitPrice, trade.entryPrice * 0.996);
    }
  } else if (trade.direction === "long") {
    exitPrice = Math.min(exitPrice, trade.entryPrice * 0.996);
  } else {
    exitPrice = Math.max(exitPrice, trade.entryPrice * 1.004);
  }

  const stakeAmt = parseFloat(Number(trade.stake));
  const manualRaw = trade.forcedAmount;
  const hasManual =
    reason === "admin_force" &&
    manualRaw != null &&
    Number.isFinite(parseFloat(manualRaw));
  const manualAmt = hasManual ? Math.abs(parseFloat(manualRaw)) : 0;

  let payout = 0;
  const fresh = await User.findById(user._id);
  const usdt = parseFloat(Number(fresh.wallet.get("USDT") || 0));

  try {
    if (outcome === "win") {
      let profit;
      let note;

      if (hasManual) {
        // Force WIN: New Balance = Current + Stake + Manual Balance Add
        profit = manualAmt;
        payout = parseFloat(stakeAmt) + parseFloat(profit);
        trade.set("payoutPercent", undefined);
        note = `Seconds WIN · stake $${stakeAmt} + manual $${profit} = $${payout} · ${reason}`;
      } else {
        let pct = DEFAULT_PAYOUT;
        const fromTrade = Number(trade.payoutPercent);
        if (Number.isFinite(fromTrade) && fromTrade > 0) pct = fromTrade;
        if (reason === "user_force_win") {
          const fromUser = Number(fresh.tradeControlPercentage);
          if (Number.isFinite(fromUser) && fromUser > 0) pct = fromUser;
        }
        profit = parseFloat(stakeAmt) * (pct / 100);
        payout = parseFloat(stakeAmt) + parseFloat(profit);
        trade.payoutPercent = pct;
        note = `Seconds WIN · stake $${stakeAmt} + ${pct}% profit $${profit} = $${payout} · ${reason}`;
      }

      fresh.wallet.set("USDT", parseFloat(usdt) + parseFloat(payout));
      fresh.markModified("wallet");
      await fresh.save();
      await Transaction.create({
        user: fresh._id,
        adminId: trade.adminId || fresh.adminId || null,
        kind: "trade",
        side: trade.direction === "long" ? "buy" : "sell",
        symbol: trade.asset,
        amount: stakeAmt,
        usdValue: payout,
        status: "completed",
        reviewerNote: note,
      });
    } else if (hasManual) {
      // Force LOSS: New Balance = Current + Stake − Manual Balance Add
      // (return remainder of stake; only |manual| is lost)
      const returned = parseFloat(stakeAmt) - parseFloat(manualAmt);
      payout = returned;
      trade.lossAmount = manualAmt;
      trade.set("payoutPercent", undefined);

      fresh.wallet.set("USDT", parseFloat(usdt) + parseFloat(returned));
      fresh.markModified("wallet");
      await fresh.save();
      await Transaction.create({
        user: fresh._id,
        adminId: trade.adminId || fresh.adminId || null,
        kind: "trade",
        side: trade.direction === "long" ? "buy" : "sell",
        symbol: trade.asset,
        amount: stakeAmt,
        usdValue: returned,
        status: "completed",
        reviewerNote: `Seconds LOSS · stake $${stakeAmt} − manual $${manualAmt} → returned $${returned} · ${reason}`,
      });
    } else {
      // Stake already deducted on open — permanent full loss, no further debit
      trade.lossAmount = stakeAmt;
      trade.set("payoutPercent", undefined);
      payout = 0;
      await Transaction.create({
        user: fresh._id,
        adminId: trade.adminId || fresh.adminId || null,
        kind: "trade",
        side: trade.direction === "long" ? "buy" : "sell",
        symbol: trade.asset,
        amount: stakeAmt,
        usdValue: 0,
        status: "completed",
        reviewerNote: `Seconds LOSS · stake −$${stakeAmt} · ${reason}`,
      });
    }

    trade.status = outcome === "win" ? "won" : "lost";
    trade.exitPrice = exitPrice;
    trade.payout = payout;
    trade.settledAt = new Date();
    trade.settleReason = reason;
    await trade.save();

    try {
      const trader = await User.findById(trade.user);
      if (trader) {
        await onTradeSettled({
          trader,
          stakeUsd: stakeAmt,
          tradeId: trade._id,
          adminId: trade.adminId || trader.adminId || null,
        });
      }
    } catch (err) {
      console.error("[referral] settle hook failed", err?.message);
    }

    // Soft-reset chart bias after settle — snap terminal back to live feed
    try {
      const u2 = await User.findById(trade.user);
      if (u2?.chartBias?.set) {
        u2.chartBias.set(trade.asset, 0);
        u2.markModified("chartBias");
        await u2.save();
      }
      // Release override lock the millisecond settlement completes
      emitChartResync(trade.user, {
        asset: trade.asset,
        exitPrice: trade.exitPrice,
        status: trade.status,
        tradeId: String(trade._id),
      });
      const wallet =
        u2?.wallet instanceof Map
          ? Object.fromEntries(u2.wallet)
          : { ...(u2?.wallet || {}) };
      emitWalletUpdate(trade.user, wallet, {
        reason: "seconds_settle",
        tradeId: String(trade._id),
      });
    } catch {
      /* ignore */
    }
    try {
      emitTradeSettled(trade);
    } catch {
      /* ignore */
    }
    return trade;
  } catch (err) {
    await SecondsTrade.findByIdAndUpdate(tradeId, { status: "open" });
    throw err;
  }
}

/** Background settler — call from server bootstrap */
export async function settleExpiredTrades() {
  if (mongoose.connection.readyState !== 1) return 0;

  // Gradually ramp chart bias — direction-aware for BUY LONG / SELL SHORT
  try {
    const forcedOpen = await SecondsTrade.find({
      status: "open",
      forcedOutcome: { $in: ["win", "loss"] },
    }).limit(40);
    for (const t of forcedOpen) {
      const user = await User.findById(t.user);
      if (!user) continue;
      if (!user.chartBias) user.chartBias = new Map();

      const opened = new Date(t.openedAt).getTime();
      const expires = new Date(t.expiresAt).getTime();
      const remainingMs = Math.max(0, expires - Date.now());
      const rampWindow = Math.max(1, expires - opened);
      const progress = Math.min(1, Math.max(0, (Date.now() - opened) / rampWindow));

      // Ease-in-out toward ~2.2% by expiry — clear on chart, still clamped client-side
      const peak = 2.2;
      const eased =
        progress < 0.5
          ? 2 * progress * progress
          : 1 - Math.pow(-2 * progress + 2, 2) / 2;
      const wiggle = Math.sin(Date.now() / 2400) * 0.06;
      const signedPeak = signedBiasForOutcome(
        t.direction,
        t.forcedOutcome,
        eased * peak + Math.abs(wiggle)
      );
      // Soft floor once locked (preserve sign)
      let target = signedBiasForOutcome(
        t.direction,
        t.forcedOutcome,
        Math.max(0.08, Math.abs(signedPeak))
      );

      const cur = Number(t.priceBiasPercent || user.chartBias.get(t.asset) || 0);
      const maxStep = 0.07;
      let next = cur;
      const goingUp = target > 0;
      if (goingUp) {
        if (cur < target) next = Math.min(target, cur + maxStep);
        else next = target + (Math.random() - 0.5) * 0.03;
        next = Math.max(0.06, next);
      } else {
        if (cur > target) next = Math.max(target, cur - maxStep);
        else next = target + (Math.random() - 0.5) * 0.03;
        next = Math.min(-0.06, next);
      }

      // Near expiry, hold direction with micro-fluctuation only
      if (remainingMs < 1500) {
        const hold = signedBiasForOutcome(t.direction, t.forcedOutcome, 0.4);
        next = hold + (Math.random() - 0.5) * 0.02;
        if (hold > 0) next = Math.max(0.4, next);
        else next = Math.min(-0.4, next);
      }

      next = Number(next.toFixed(4));
      user.chartBias.set(t.asset, next);
      user.markModified("chartBias");
      await user.save();
      t.priceBiasPercent = next;
      await t.save();
    }
  } catch (err) {
    console.error("[seconds-trade] bias ramp failed", err?.message);
  }

  // Unstick crashed mid-settle claims
  await SecondsTrade.updateMany(
    {
      status: "settling",
      updatedAt: { $lte: new Date(Date.now() - 15000) },
    },
    { $set: { status: "open" } }
  );
  const now = new Date();
  const expired = await SecondsTrade.find({
    status: "open",
    expiresAt: { $lte: now },
  }).limit(50);
  for (const t of expired) {
    try {
      // Honor Force / Graph lock already stamped — settle only after timer hit 0
      if (t.forcedOutcome === "win" || t.forcedOutcome === "loss") {
        await settleTrade(t._id, { forceOutcome: t.forcedOutcome });
      } else {
        await settleTrade(t._id);
      }
    } catch (err) {
      console.error("[seconds-trade] settle failed", t._id, err?.message);
    }
  }
  return expired.length;
}

// ---------------------------------------------------------------------------
// GET /public-markets — no auth (landing page ticker / charts)
// ---------------------------------------------------------------------------
router.get(
  "/public-markets",
  asyncHandler(async (_req, res) => {
    const assets = [
      ...CRYPTO_ASSETS.map((a) => ({ asset: a, assetType: "crypto" })),
      ...FOREX_ASSETS.map((a) => ({ asset: a, assetType: "forex" })),
      ...STOCK_ASSETS.map((a) => ({ asset: a, assetType: "stock" })),
    ];
    const tickerMap = await fetchBinanceTickerMap();
    const markets = await Promise.all(
      assets.map(async ({ asset, assetType }) => {
        const quote = assetType === "crypto" ? "USDT" : "USD";
        const price = await fetchLivePrice(asset, tickerMap, quote);
        const priceUsdc =
          assetType === "crypto"
            ? await fetchLivePrice(asset, tickerMap, "USDC")
            : price;
        return {
          asset,
          assetType,
          quote,
          price,
          quotes: assetType === "crypto" ? { USDT: price, USDC: priceUsdc } : undefined,
        };
      })
    );
    res.json({
      success: true,
      markets,
      serverTime: new Date().toISOString(),
    });
  })
);

// ---------------------------------------------------------------------------
// GET /markets
// ---------------------------------------------------------------------------
router.get(
  "/markets",
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.auth.sub).select("chartBias chartQuote");
    const biasMap = walletToObject(user?.chartBias);
    const chartQuote = normalizeQuote(user?.chartQuote || null, "crypto");
    const forcedQuote = user?.chartQuote ? chartQuote : null;

    const assets = [
      ...CRYPTO_ASSETS.map((a) => ({ asset: a, assetType: "crypto" })),
      ...FOREX_ASSETS.map((a) => ({ asset: a, assetType: "forex" })),
      ...STOCK_ASSETS.map((a) => ({ asset: a, assetType: "stock" })),
    ];

    const tickerMap = await fetchBinanceTickerMap();

    const prices = await Promise.all(
      assets.map(async ({ asset, assetType }) => {
        const priceUsdt = await fetchLivePrice(asset, tickerMap, "USDT");
        const priceUsdc =
          assetType === "crypto"
            ? await fetchLivePrice(asset, tickerMap, "USDC")
            : priceUsdt;
        const bias = Number(biasMap[asset] || 0);
        return {
          asset,
          assetType,
          rawPrice: priceUsdt,
          rawUsdc: priceUsdc,
          biasPercent: bias,
        };
      })
    );

    // Open-trade bias overrides user chartBias (never sum — that caused 2× spikes)
    const open = await SecondsTrade.find({
      user: req.auth.sub,
      status: "open",
    }).select("asset priceBiasPercent");

    const tradeBias = {};
    for (const t of open) {
      const b = Number(t.priceBiasPercent || 0);
      // Prefer the strongest absolute bias if multiple open on same asset
      if (
        tradeBias[t.asset] == null ||
        Math.abs(b) > Math.abs(tradeBias[t.asset])
      ) {
        tradeBias[t.asset] = b;
      }
    }

    const merged = prices.map((p) => {
      const hasTrade = Object.prototype.hasOwnProperty.call(tradeBias, p.asset);
      const bias = hasTrade ? tradeBias[p.asset] : p.biasPercent;
      const usdt = applyBias(p.rawPrice, bias);
      const usdc = applyBias(p.rawUsdc, bias);
      return {
        asset: p.asset,
        assetType: p.assetType,
        quote: p.assetType === "crypto" ? forcedQuote || "USDT" : "USD",
        price: usdt,
        quotes:
          p.assetType === "crypto" ? { USDT: usdt, USDC: usdc } : undefined,
      };
    });

    res.json({
      success: true,
      markets: merged,
      chartQuote: forcedQuote,
      serverTime: new Date().toISOString(),
    });
  })
);

// ---------------------------------------------------------------------------
// POST /open
// ---------------------------------------------------------------------------
router.post(
  "/open",
  requireAuth,
  requireDatabase,
  [
    body("asset").isString().trim().isLength({ min: 2, max: 24 }),
    body("direction").isIn(["long", "short"]),
    body("stake").isFloat({ gt: 0 }),
    body("durationSec").isInt({ min: MIN_DURATION, max: MAX_DURATION }),
    body("entryPrice").optional().isFloat({ gt: 0 }),
    body("quote").optional().isString().trim().isLength({ min: 3, max: 8 }),
  ],
  asyncHandler(async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return sendValidationError(res, errors);

    const asset = String(req.body.asset).toUpperCase();
    const direction = req.body.direction;
    const stake = Number(req.body.stake);
    const durationSec = Number(req.body.durationSec);
    const assetType = resolveAssetType(asset);

    if (!assetType) {
      return res.status(400).json({
        success: false,
        error: "BadRequestError",
        message: "Unsupported asset.",
      });
    }

    let quote = normalizeQuote(req.body.quote, assetType);

    const user = await User.findById(req.auth.sub);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: "NotFoundError",
        message: "User not found.",
      });
    }
    if (user.banned) {
      return res.status(403).json({
        success: false,
        error: "ForbiddenError",
        message: "Account is suspended.",
      });
    }
    if (assetType === "crypto" && user.chartQuote) {
      quote = normalizeQuote(user.chartQuote, "crypto");
    }

    const platform = await PlatformConfig.getSingleton();
    if (platform.globalTradingEnabled === false) {
      return res.status(403).json({
        success: false,
        error: "TradingSuspended",
        message: "Trading will start soon",
        tradingSuspended: true,
        reason: "global",
      });
    }
    if (user.tradingAllowed === false) {
      return res.status(403).json({
        success: false,
        error: "TradingSuspended",
        message: "Trading will start soon",
        tradingSuspended: true,
        reason: "user",
      });
    }

    const rawAvailable = Number(user.wallet.get("USDT") || 0);
    const available = Number(rawAvailable.toFixed(8));
    let stakeAmt = Number(Number(stake).toFixed(8));
    if (!Number.isFinite(stakeAmt) || stakeAmt <= 0) {
      return res.status(400).json({
        success: false,
        error: "BadRequestError",
        message: "Enter a valid stake.",
      });
    }
    // Full-wallet stake: if user asks for ~all balance (or slightly more from UI rounding), clamp to exact available
    let maxAllIn = false;
    if (stakeAmt >= available - 0.02 || Math.abs(stakeAmt - available) <= 0.05) {
      stakeAmt = available;
      maxAllIn = available > 0;
    }
    if (stakeAmt > available + 1e-8) {
      return res.status(400).json({
        success: false,
        error: "InsufficientFunds",
        message: `Need ${stakeAmt} USDT — wallet has ${available.toFixed(2)}.`,
      });
    }
    if (available <= 0 || stakeAmt <= 0) {
      return res.status(400).json({
        success: false,
        error: "InsufficientFunds",
        message: "Insufficient Trading Wallet balance.",
      });
    }

    let entryPrice = Number(req.body.entryPrice);
    if (!Number.isFinite(entryPrice) || entryPrice <= 0) {
      entryPrice = await fetchLivePrice(asset, null, quote);
    }
    const chartBias = Number(
      user.chartBias?.get?.(asset) || user.chartBias?.[asset] || 0
    );
    entryPrice = applyBias(entryPrice, chartBias);

    const nextBal = Number(Math.max(0, available - stakeAmt).toFixed(8));
    user.wallet.set("USDT", nextBal);
    user.markModified("wallet");
    await user.save();

    const openedAt = new Date();
    const expiresAt = new Date(openedAt.getTime() + durationSec * 1000);

    const tenantId = user.adminId || null;

    const trade = await SecondsTrade.create({
      user: user._id,
      adminId: tenantId,
      asset,
      quote,
      assetType,
      direction,
      stake: stakeAmt,
      durationSec,
      entryPrice,
      payoutPercent: DEFAULT_PAYOUT,
      maxAllIn,
      openedAt,
      expiresAt,
      status: "open",
    });

    await Transaction.create({
      user: user._id,
      adminId: tenantId,
      kind: "trade",
      side: direction === "long" ? "buy" : "sell",
      symbol: asset,
      amount: stakeAmt,
      usdValue: stakeAmt,
      status: "completed",
      reviewerNote: `Seconds trade OPEN ${direction.toUpperCase()} ${durationSec}s`,
    });

    try {
      emitTradeOpened(trade, {
        username: user.username,
        email: user.email,
        fullName: user.fullName,
      });
      const wallet = walletToObject(user.wallet);
      emitWalletUpdate(user._id, wallet, {
        reason: "seconds_open",
        tradeId: String(trade._id),
      });
    } catch {
      /* ignore socket failures */
    }

    res.status(201).json({
      success: true,
      trade: serializeTrade(trade),
      user: {
        id: user._id,
        wallet: walletToObject(user.wallet),
      },
    });
  })
);

// ---------------------------------------------------------------------------
// GET /active
// ---------------------------------------------------------------------------
router.get(
  "/active",
  requireAuth,
  requireDatabase,
  asyncHandler(async (req, res) => {
    // Opportunistic settle
    const due = await SecondsTrade.find({
      user: req.auth.sub,
      status: "open",
      expiresAt: { $lte: new Date() },
    }).limit(20);
    for (const t of due) {
      await settleTrade(t._id);
    }

    const trades = await SecondsTrade.find({
      user: req.auth.sub,
      status: "open",
    }).sort({ openedAt: -1 });

    res.json({
      success: true,
      trades: trades.map(serializeTrade),
      serverTime: new Date().toISOString(),
    });
  })
);

// ---------------------------------------------------------------------------
// GET /history
// ---------------------------------------------------------------------------
router.get(
  "/history",
  requireAuth,
  requireDatabase,
  asyncHandler(async (req, res) => {
    const trades = await SecondsTrade.find({
      user: req.auth.sub,
      status: { $in: ["won", "lost", "cancelled"] },
    })
      .sort({ settledAt: -1, createdAt: -1 })
      .limit(200);

    const serialized = trades.map(serializeTrade);

    // Daily P/L rollup (UTC date key)
    const byDay = {};
    for (const t of serialized) {
      const when = t.settledAt || t.createdAt;
      const day = new Date(when).toISOString().slice(0, 10);
      if (!byDay[day]) {
        byDay[day] = {
          date: day,
          wins: 0,
          losses: 0,
          profit: 0,
          lossAmount: 0,
          net: 0,
        };
      }
      const row = byDay[day];
      if (t.status === "won") {
        const profit = Math.max(0, Number(t.payout || 0) - Number(t.stake || 0));
        row.wins += 1;
        row.profit += profit;
        row.net += profit;
      } else if (t.status === "lost") {
        row.losses += 1;
        row.lossAmount += Number(t.stake || 0);
        row.net -= Number(t.stake || 0);
      }
    }
    const daily = Object.values(byDay).sort((a, b) =>
      a.date < b.date ? 1 : -1
    );

    const wins = serialized.filter((t) => t.status === "won");
    const profit = wins.reduce(
      (s, t) => s + Math.max(0, Number(t.payout || 0) - Number(t.stake || 0)),
      0
    );

    res.json({
      success: true,
      trades: serialized,
      daily,
      totals: {
        wins: wins.length,
        losses: serialized.filter((t) => t.status === "lost").length,
        profit,
        net: daily.reduce((s, d) => s + d.net, 0),
      },
    });
  })
);

// ---------------------------------------------------------------------------
// POST /settle/:id
// ---------------------------------------------------------------------------
router.post(
  "/settle/:id",
  requireAuth,
  requireDatabase,
  [param("id").isMongoId()],
  asyncHandler(async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return sendValidationError(res, errors);

    const trade = await SecondsTrade.findById(req.params.id);
    if (!trade || String(trade.user) !== String(req.auth.sub)) {
      return res.status(404).json({
        success: false,
        error: "NotFoundError",
        message: "Trade not found.",
      });
    }

    if (trade.status !== "open" && trade.status !== "settling") {
      const userDone = await User.findById(req.auth.sub);
      return res.json({
        success: true,
        trade: serializeTrade(trade),
        user: userDone
          ? { id: userDone._id, wallet: walletToObject(userDone.wallet) }
          : null,
      });
    }

    // Settle only at/after exact expiry — never early (admin force does not close early)
    if (
      trade.status === "open" &&
      Date.now() < new Date(trade.expiresAt).getTime()
    ) {
      return res.status(400).json({
        success: false,
        error: "TooEarly",
        message: "Trade has not expired yet.",
        trade: serializeTrade(trade),
      });
    }

    let settled = await settleTrade(trade._id, {
      exitPriceHint: req.body?.exitPrice,
    });
    // Ensure clients always get a terminal won/lost status for toast mapping
    if (settled?.status === "settling") {
      await new Promise((r) => setTimeout(r, 350));
      settled = await SecondsTrade.findById(trade._id);
    }
    const user = await User.findById(req.auth.sub);

    res.json({
      success: true,
      trade: serializeTrade(settled),
      user: user
        ? { id: user._id, wallet: walletToObject(user.wallet) }
        : null,
    });
  })
);

export default router;
export { CRYPTO_ASSETS, STOCK_ASSETS, FALLBACK_PRICES, fetchLivePrice };
