/**
 * =============================================================================
 *  NEXUS BACKEND — server.js
 * =============================================================================
 *  Production-clean Express bootstrap for the Nexus crypto platform.
 *    Routers: auth, admin, chat, trade, wallet, staking.
 * =============================================================================
 */

import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import mongoose from "mongoose";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";

import authRoutes from "./routes/auth.js";
import adminRoutes from "./routes/admin.js";
import chatRoutes from "./routes/chat.js";
import tradeRoutes from "./routes/trade.js";
import walletRoutes from "./routes/wallet.js";
import stakingRoutes from "./routes/staking.js";
import gatewayRoutes from "./routes/gateway.js";
import secondsTradeRoutes, {
  settleExpiredTrades,
} from "./routes/secondsTrade.js";
import platformRoutes from "./routes/platform.js";
import aiBotRoutes from "./routes/aiBot.js";
import { runVipUpgradeSweep } from "./lib/referralEngine.js";
import { initSocket } from "./socket.js";
import User from "./models/User.js";
import { ROLES } from "./lib/roles.js";
import { getSoleSuperAdmin } from "./lib/superAdmin.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, ".env") });

const PORT = process.env.PORT || 5001;
const MONGO_URI =
  process.env.MONGO_URI || "mongodb://127.0.0.1:27017/nexus_dev";
const NODE_ENV = process.env.NODE_ENV || "development";

let DB_READY = false;

const app = express();

app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(morgan(NODE_ENV === "production" ? "combined" : "dev"));

app.use(
  cors({
    origin: "*",
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"],
    credentials: false,
    optionsSuccessStatus: 204,
  })
);
app.options("*", cors());

app.use(express.json({ limit: "10mb" })); // KYC document + selfie data URLs
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.get("/health", (_req, res) => {
  res.status(200).json({
    status: "ok",
    service: "nexus-api",
    env: NODE_ENV,
    uptime: process.uptime(),
    database: DB_READY ? "connected" : "offline",
    timestamp: new Date().toISOString(),
  });
});

app.get("/api/health", (_req, res) => {
  res.status(200).json({
    status: "ok",
    service: "nexus-api",
    env: NODE_ENV,
    uptime: process.uptime(),
    database: DB_READY ? "connected" : "offline",
    timestamp: new Date().toISOString(),
  });
});

app.get("/", (_req, res) => {
  res.status(200).json({
    message: "Nexus API is online.",
    docs: "/health",
    version: "1.5.1",
  });
});

// Feature routers
app.use("/api/auth", authRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/trade", tradeRoutes);
app.use("/api/wallet", walletRoutes);
app.use("/api/staking", stakingRoutes);
app.use("/api/gateway", gatewayRoutes);
app.use("/api/seconds-trade", secondsTradeRoutes);
app.use("/api/platform", platformRoutes);
app.use("/api/ai-bot", aiBotRoutes);

// 404
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: "NotFound",
    message: `Route ${req.method} ${req.originalUrl} not found.`,
  });
});

// Global error handler
// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  const status = err.status || err.statusCode || 500;
  const payload = {
    success: false,
    error: err.name || "InternalServerError",
    message: err.message || "An unexpected error occurred.",
  };
  if (NODE_ENV !== "production" && err.stack) payload.stack = err.stack;
  res.status(status).json(payload);
});

/**
 * Live SUPER_ADMIN upsert — only the sole authorized account.
 * Demotes every other SUPER_ADMIN so old emails cannot open the console.
 */
const ensureSeedSuperAdmin = async () => {
  try {
    const { email, username, password, fullName } = getSoleSuperAdmin();
    if (!email || !password || password.length < 8) return;

    let user = await User.findOne({ email }).select("+password");
    if (!user) {
      user = await User.findOne({ username }).select("+password");
    }

    const hashed = await bcrypt.hash(password, 12);

    if (!user) {
      await User.create({
        fullName,
        username,
        email,
        password: hashed,
        role: ROLES.SUPER_ADMIN,
        adminId: null,
        banned: false,
        deletedAt: null,
      });
      console.log(`\x1b[32m[migrate]\x1b[0m Created SUPER_ADMIN ${email}`);
    } else {
      let changed = false;
      const matches = user.password
        ? await bcrypt.compare(password, user.password)
        : false;

      if (!matches) {
        user.password = hashed;
        changed = true;
      }
      if (user.role !== ROLES.SUPER_ADMIN) {
        user.role = ROLES.SUPER_ADMIN;
        changed = true;
      }
      if (user.username !== username) {
        // Avoid unique clashes — only rename when free
        const taken = await User.findOne({
          username,
          _id: { $ne: user._id },
        }).select("_id");
        if (!taken) {
          user.username = username;
          changed = true;
        }
      }
      if (user.email !== email) {
        const taken = await User.findOne({
          email,
          _id: { $ne: user._id },
        }).select("_id");
        if (!taken) {
          user.email = email;
          changed = true;
        }
      }
      if (user.adminId) {
        user.adminId = null;
        changed = true;
      }
      if (user.banned) {
        user.banned = false;
        changed = true;
      }
      if (user.deletedAt) {
        user.deletedAt = null;
        changed = true;
      }
      if (user.fullName !== fullName) {
        user.fullName = fullName;
        changed = true;
      }

      if (changed) {
        await user.save();
        console.log(
          `\x1b[32m[migrate]\x1b[0m Synced SUPER_ADMIN ${email} (role + password).`
        );
      }
    }

    // Strip SUPER_ADMIN from every other account (forces old sessions off console)
    const demote = await User.updateMany(
      {
        role: ROLES.SUPER_ADMIN,
        email: { $ne: email },
        username: { $ne: username },
      },
      { $set: { role: ROLES.USER } }
    );
    if (demote.modifiedCount > 0) {
      console.log(
        `\x1b[33m[migrate]\x1b[0m Demoted ${demote.modifiedCount} unauthorized SUPER_ADMIN account(s).`
      );
    }
  } catch (err) {
    console.warn(
      `\x1b[33m[migrate]\x1b[0m SUPER_ADMIN ensure skipped: ${err?.message || err}`
    );
  }
};

const connectDatabase = async () => {
  try {
    mongoose.set("strictQuery", true);
    await mongoose.connect(MONGO_URI, {
      serverSelectionTimeoutMS: 8000,
      autoIndex: NODE_ENV !== "production",
    });
    DB_READY = true;
    console.log(`\x1b[32m[db]\x1b[0m MongoDB connected.`);
    await ensureSeedSuperAdmin();

    mongoose.connection.on("disconnected", () => {
      DB_READY = false;
      console.warn("\x1b[33m[db]\x1b[0m MongoDB disconnected.");
    });
    mongoose.connection.on("reconnected", () => {
      DB_READY = true;
      console.log("\x1b[32m[db]\x1b[0m MongoDB reconnected.");
    });
  } catch (err) {
    DB_READY = false;
    console.warn(
      "\x1b[33m[db]\x1b[0m ⚠️  MongoDB connection failed — running in DEGRADED mode.\n" +
        `      reason: ${err?.message || err}`
    );
  }
};

const server = http.createServer(app);
initSocket(server);

server.listen(PORT, "0.0.0.0", () => {
  console.log(
    `\x1b[36m[api]\x1b[0m Nexus server listening on http://0.0.0.0:${PORT}`
  );
  console.log(`\x1b[36m[api]\x1b[0m Environment: ${NODE_ENV}`);
  console.log(`\x1b[36m[api]\x1b[0m Socket.IO realtime channel online.`);
  connectDatabase();
});

// Settle expired seconds trades every 1s (timer must complete to 0, then settle)
const settler = setInterval(() => {
  settleExpiredTrades().catch(() => {});
}, 1000);
settler.unref?.();

// Daily VIP auto-upgrade from 30-day trading volume (also runs once after boot)
const vipSweep = async () => {
  try {
    const n = await runVipUpgradeSweep();
    if (n) console.log(`[vip] auto-upgraded ${n} user(s)`);
  } catch {
    /* ignore */
  }
};
setTimeout(vipSweep, 20_000).unref?.();
const vipTimer = setInterval(vipSweep, 24 * 60 * 60 * 1000);
vipTimer.unref?.();

process.on("unhandledRejection", (reason) => {
  console.error("\x1b[31m[unhandledRejection]\x1b[0m", reason);
});
process.on("uncaughtException", (err) => {
  console.error("\x1b[31m[uncaughtException]\x1b[0m", err);
});

const shutdown = (signal) => {
  console.log(`\n\x1b[36m[api]\x1b[0m Received ${signal}. Shutting down...`);
  server.close(() => {
    mongoose.connection
      .close(false)
      .catch(() => {})
      .finally(() => process.exit(0));
  });
};
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

export default app;
