/**
 * =============================================================================
 *  NEXUS FRONTEND — src/components/Dashboard.jsx
 * =============================================================================
 *  Mobile-first Seconds Trading hub.
 *    Tabs via sticky bottom nav: Home | Wallet | Trade | History
 *    Side drawer for profile / KYC / admin / sign out
 * =============================================================================
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { isStaffRole } from "../lib/roles.js";
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  LogOut,
  Bell,
  Search,
  RefreshCw,
  Coins,
  BarChart3,
  Activity,
  ShieldCheck,
  Copy,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  X,
  Send,
  ArrowDownToLine,
  ArrowUpFromLine,
  History,
  Bot,
  BadgeCheck,
  MessageCircle,
} from "lucide-react";

import LiveChatWidget from "./LiveChatWidget.jsx";
import KYCModule from "./KYCModule.jsx";
import AppShell from "./AppShell.jsx";
import PlatformShell from "./PlatformShell.jsx";
import {
  MarketPage,
  LoanPage,
  AssetsHubPage,
  ReferralSection,
} from "./PlatformModules.jsx";
import AiBotTradingPage from "./AiBotTrading.jsx";
import HomeLanding from "./HomeLanding.jsx";
import SecondsTrading from "./SecondsTrading.jsx";
import CryptoWatchlist from "./CryptoWatchlist.jsx";
import MarketActivity from "./MarketActivity.jsx";
import TradeHistory from "./TradeHistory.jsx";
import ProfileSetup from "./ProfileSetup.jsx";
import DepositSection from "./DepositSection.jsx";
import WithdrawSection from "./WithdrawSection.jsx";
import { AboutPage, ContactPage, VipPage } from "./InfoPages.jsx";
import { CertificatePage } from "./TradingCertificate.jsx";
import { AuthAPI, WalletAPI, SecondsTradeAPI, clearToken } from "../lib/api.js";
import { getSocket, onSocketEvent, disconnectSocket } from "../lib/socket.js";

// ---------------------------------------------------------------------------
// Constants + mock market seed
// ---------------------------------------------------------------------------
const seedSpark = (base, drift = 0.02, len = 60) => {
  const out = [base];
  for (let i = 1; i < len; i++) {
    const step = (Math.random() - 0.5) * drift * base;
    out.push(Math.max(0.0001, out[i - 1] + step));
  }
  return out;
};

const MARKET_SEED = [
  { symbol: "BTC", name: "Bitcoin", price: 68240, change: 2.14 },
  { symbol: "ETH", name: "Ethereum", price: 3520, change: 1.28 },
  { symbol: "SOL", name: "Solana", price: 168, change: 4.62 },
  { symbol: "USDT", name: "Tether", price: 1.0, change: 0.01 },
  { symbol: "XRP", name: "XRP", price: 0.58, change: -0.87 },
  { symbol: "ADA", name: "Cardano", price: 0.42, change: 3.02 },
];

const fmtUSD = (n) =>
  Number(n).toLocaleString(undefined, {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: Number(n) < 1 ? 4 : 2,
  });
const fmt = (n, d = 6) =>
  Number(n).toLocaleString(undefined, { maximumFractionDigits: d });

// ---------------------------------------------------------------------------
// Toast
// ---------------------------------------------------------------------------
const Toast = ({ kind, message, onClose }) => (
  <AnimatePresence>
    {message && (
      <motion.div
        initial={{ opacity: 0, y: -20, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -14, scale: 0.96 }}
        transition={{ type: "spring", stiffness: 320, damping: 24 }}
        className={`fixed left-1/2 top-6 z-50 -translate-x-1/2 rounded-xl border px-4 py-2.5 shadow-2xl backdrop-blur-xl ${
          kind === "success"
            ? "border-emerald-400/25 bg-emerald-500/10 text-emerald-200"
            : "border-rose-400/25 bg-rose-500/10 text-rose-200"
        }`}
      >
        <div className="flex items-center gap-2.5">
          {kind === "success" ? (
            <CheckCircle2 className="h-4 w-4" />
          ) : (
            <AlertTriangle className="h-4 w-4" />
          )}
          <span className="text-sm font-medium">{message}</span>
          <button
            onClick={onClose}
            className="ml-2 rounded p-0.5 opacity-70 hover:opacity-100"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </motion.div>
    )}
  </AnimatePresence>
);

// ---------------------------------------------------------------------------
// Sparkline (used in watchlist)
// ---------------------------------------------------------------------------
const Sparkline = ({ points, positive = true, width = 96, height = 32 }) => {
  const min = Math.min(...points);
  const max = Math.max(...points);
  const range = max - min || 1;
  const step = width / (points.length - 1);
  const d = points
    .map((v, i) => {
      const x = i * step;
      const y = height - ((v - min) / range) * height;
      return `${i === 0 ? "M" : "L"}${x.toFixed(2)},${y.toFixed(2)}`;
    })
    .join(" ");
  const stroke = positive ? "#34d399" : "#fb7185";
  const fill = positive ? "rgba(52,211,153,0.15)" : "rgba(251,113,133,0.15)";
  const area = `${d} L${width},${height} L0,${height} Z`;
  return (
    <svg width={width} height={height} className="overflow-visible">
      <path d={area} fill={fill} />
      <path
        d={d}
        fill="none"
        stroke={stroke}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

// ---------------------------------------------------------------------------
// PriceChart — main interactive live chart (BTC/ETH)
// ---------------------------------------------------------------------------
const PriceChart = ({ symbol, series, name }) => {
  const W = 900;
  const H = 320;
  const pad = { top: 20, right: 60, bottom: 24, left: 10 };
  const min = Math.min(...series);
  const max = Math.max(...series);
  const range = max - min || 1;
  const step = (W - pad.left - pad.right) / (series.length - 1);
  const xy = series.map((v, i) => {
    const x = pad.left + i * step;
    const y = pad.top + ((max - v) / range) * (H - pad.top - pad.bottom);
    return [x, y];
  });
  const d = xy
    .map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`)
    .join(" ");
  const area = `${d} L${xy[xy.length - 1][0]},${H - pad.bottom} L${xy[0][0]},${
    H - pad.bottom
  } Z`;

  const last = series[series.length - 1];
  const first = series[0];
  const change = ((last - first) / first) * 100;
  const positive = change >= 0;

  // Y-axis labels (5 tiers)
  const yLabels = [];
  for (let i = 0; i <= 4; i++) {
    const value = max - (range / 4) * i;
    const y = pad.top + (i / 4) * (H - pad.top - pad.bottom);
    yLabels.push({ value, y });
  }

  return (
    <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-5 backdrop-blur-sm">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-lg bg-emerald-500/15 text-[11px] font-bold text-emerald-300">
            {symbol}
          </div>
          <div>
            <div className="text-sm font-semibold">
              {name}/USDT
            </div>
            <div className="text-[10px] uppercase tracking-widest text-slate-500">
              Live spot · Simulation
            </div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-lg font-bold tabular-nums">{fmtUSD(last)}</div>
          <div
            className={`inline-flex items-center gap-1 text-xs font-semibold ${
              positive ? "text-emerald-400" : "text-rose-400"
            }`}
          >
            {positive ? (
              <TrendingUp className="h-3 w-3" />
            ) : (
              <TrendingDown className="h-3 w-3" />
            )}
            {positive ? "+" : ""}
            {change.toFixed(2)}%
          </div>
        </div>
      </div>

      <svg viewBox={`0 0 ${W} ${H}`} className="w-full">
        <defs>
          <linearGradient id={`grad-${symbol}`} x1="0" y1="0" x2="0" y2="1">
            <stop
              offset="0%"
              stopColor={positive ? "#34d399" : "#fb7185"}
              stopOpacity="0.4"
            />
            <stop
              offset="100%"
              stopColor={positive ? "#34d399" : "#fb7185"}
              stopOpacity="0"
            />
          </linearGradient>
          <filter id={`glow-${symbol}`} x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Y grid */}
        {yLabels.map((yl, i) => (
          <g key={i}>
            <line
              x1={pad.left}
              y1={yl.y}
              x2={W - pad.right}
              y2={yl.y}
              stroke="rgba(255,255,255,0.05)"
              strokeDasharray="3 4"
            />
            <text
              x={W - pad.right + 6}
              y={yl.y + 3}
              fill="#64748b"
              fontSize="10"
              fontFamily="ui-monospace, monospace"
            >
              {yl.value.toFixed(yl.value > 100 ? 0 : 2)}
            </text>
          </g>
        ))}

        {/* Area */}
        <path d={area} fill={`url(#grad-${symbol})`} />

        {/* Line */}
        <path
          d={d}
          fill="none"
          stroke={positive ? "#34d399" : "#fb7185"}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          filter={`url(#glow-${symbol})`}
        />

        {/* Current price marker */}
        <g>
          <line
            x1={xy[xy.length - 1][0]}
            y1={pad.top}
            x2={xy[xy.length - 1][0]}
            y2={H - pad.bottom}
            stroke={positive ? "#34d399" : "#fb7185"}
            strokeOpacity="0.15"
            strokeDasharray="2 3"
          />
          <circle
            cx={xy[xy.length - 1][0]}
            cy={xy[xy.length - 1][1]}
            r="8"
            fill={positive ? "#34d399" : "#fb7185"}
            fillOpacity="0.15"
          >
            <animate
              attributeName="r"
              values="6;12;6"
              dur="1.6s"
              repeatCount="indefinite"
            />
          </circle>
          <circle
            cx={xy[xy.length - 1][0]}
            cy={xy[xy.length - 1][1]}
            r="4"
            fill={positive ? "#34d399" : "#fb7185"}
          />
        </g>
      </svg>
    </div>
  );
};

// ---------------------------------------------------------------------------
// SpotTrade — connected to backend
// ---------------------------------------------------------------------------
const SpotTrade = ({ symbol, price, wallet, onExecuted, toast }) => {
  const [side, setSide] = useState("buy");
  const [amount, setAmount] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const usdt = wallet?.USDT || 0;
  const assetBal = wallet?.[symbol] || 0;

  const usdValue = (parseFloat(amount) || 0) * price;

  const handleSubmit = async (e) => {
    e.preventDefault();
    const amt = parseFloat(amount);
    if (!amt || amt <= 0 || submitting) return;
    setSubmitting(true);
    try {
      const res = await TradeAPI.execute({ side, symbol, amount: amt, price });
      onExecuted?.(res.user);
      setAmount("");
      // Server signals force-loss with override === "force_loss" so the
      // toast can turn red even though the request itself succeeded.
      const kind = res?.override === "force_loss" ? "error" : "success";
      toast(kind, res.message || "Trade filled.");
    } catch (err) {
      toast("error", err?.message || "Trade failed.");
    } finally {
      setSubmitting(false);
    }
  };

  const fill = (pct) => {
    if (side === "buy") {
      setAmount(((usdt * pct) / price).toFixed(6));
    } else {
      setAmount((assetBal * pct).toFixed(6));
    }
  };

  return (
    <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-5 backdrop-blur-sm">
      <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold tracking-tight">
        <Activity className="h-4 w-4 text-indigo-300" /> Spot Order
      </h3>

      <div className="mb-3 grid grid-cols-2 gap-1 rounded-xl bg-white/[0.03] p-1">
        {["buy", "sell"].map((s) => (
          <button
            key={s}
            onClick={() => setSide(s)}
            className={`relative rounded-lg py-2 text-xs font-semibold uppercase tracking-wider transition ${
              side === s
                ? s === "buy"
                  ? "text-emerald-300"
                  : "text-rose-300"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            {side === s && (
              <motion.span
                layoutId="spot-pill"
                className={`absolute inset-0 rounded-lg ${
                  s === "buy" ? "bg-emerald-500/15" : "bg-rose-500/15"
                }`}
              />
            )}
            <span className="relative">{s}</span>
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3">
          <div className="mb-1 flex items-center justify-between text-[10px] uppercase tracking-widest text-slate-500">
            <span>Amount ({symbol})</span>
            <span>
              Bal: {fmt(side === "buy" ? usdt : assetBal, 4)}{" "}
              {side === "buy" ? "USDT" : symbol}
            </span>
          </div>
          <input
            type="number"
            step="any"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
            className="w-full bg-transparent text-lg font-semibold text-slate-100 outline-none placeholder:text-slate-600"
          />
          <div className="mt-1 text-[11px] text-slate-500">
            ≈ {fmtUSD(usdValue)}
          </div>
        </div>

        <div className="grid grid-cols-4 gap-1">
          {[0.25, 0.5, 0.75, 1].map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => fill(p)}
              className="rounded-lg border border-white/5 bg-white/[0.02] py-1 text-[10px] font-semibold text-slate-400 hover:bg-white/[0.05] hover:text-slate-200"
            >
              {p * 100}%
            </button>
          ))}
        </div>

        <motion.button
          type="submit"
          disabled={submitting || !parseFloat(amount)}
          whileHover={!submitting ? { scale: 1.01 } : undefined}
          whileTap={!submitting ? { scale: 0.99 } : undefined}
          className={`flex w-full items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold text-white shadow-lg disabled:opacity-60 ${
            side === "buy"
              ? "bg-gradient-to-r from-emerald-500 to-emerald-400 shadow-emerald-500/25"
              : "bg-gradient-to-r from-rose-500 to-rose-400 shadow-rose-500/25"
          }`}
        >
          {submitting ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" /> Executing…
            </>
          ) : (
            <>
              {side === "buy" ? (
                <ArrowUpRight className="h-4 w-4" />
              ) : (
                <ArrowDownRight className="h-4 w-4" />
              )}
              {side === "buy" ? "Buy" : "Sell"} {symbol}
            </>
          )}
        </motion.button>
      </form>
    </div>
  );
};

// ---------------------------------------------------------------------------
// DepositPanel — dynamic bank / EasyPaisa / USDT rails from admin gateway
// ---------------------------------------------------------------------------
const GatewayField = ({ label, value, onCopy }) => {
  if (!value) return null;
  return (
    <div className="rounded-xl border border-white/5 bg-white/[0.03] p-3">
      <div className="mb-1 flex items-center justify-between">
        <div className="text-[10px] font-semibold uppercase tracking-widest text-emerald-300">
          {label}
        </div>
        <button
          type="button"
          onClick={() => onCopy(value, label)}
          className="rounded-lg border border-emerald-400/20 bg-emerald-500/10 p-1 text-emerald-200 hover:bg-emerald-500/15"
        >
          <Copy className="h-3 w-3" />
        </button>
      </div>
      <code className="block break-all rounded-lg bg-black/30 px-2 py-1.5 font-mono text-[11px] text-emerald-100">
        {value}
      </code>
    </div>
  );
};

const DepositPanel = ({ toast }) => {
  const [symbol, setSymbol] = useState("USDT");
  const [amount, setAmount] = useState("");
  const [txHash, setTxHash] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const [gateway, setGateway] = useState(null);
  const [gwLoading, setGwLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setGwLoading(true);
    GatewayAPI.current()
      .then((r) => {
        if (!cancelled) setGateway(r.settings || {});
      })
      .catch(() => {
        if (!cancelled) setGateway({});
      })
      .finally(() => {
        if (!cancelled) setGwLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const copy = (value, label) => {
    try {
      navigator.clipboard?.writeText(value);
      toast("success", `${label} copied.`);
    } catch {
      /* ignore */
    }
  };

  const railList = Array.isArray(gateway?.rails)
    ? gateway.rails.filter((r) => String(r?.value || "").trim())
    : [];
  const uploadList = Array.isArray(gateway?.uploads) ? gateway.uploads : [];
  const hasAnyRail =
    gateway &&
    (railList.length > 0 ||
      gateway.accountNumber ||
      gateway.easyPaisaNumber ||
      gateway.jazzCashNumber ||
      gateway.usdtTrc20Address ||
      gateway.usdtErc20Address ||
      uploadList.length > 0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (submitting || !parseFloat(amount)) return;
    setSubmitting(true);
    try {
      const res = await WalletAPI.depositRequest({
        symbol,
        amount: parseFloat(amount),
        network: "MANUAL",
        txHash: txHash || null,
      });
      toast("success", res.message || "Deposit submitted.");
      setAmount("");
      setTxHash("");
    } catch (err) {
      toast("error", err?.message || "Deposit failed.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-5 backdrop-blur-sm">
      <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold tracking-tight">
        <ArrowDownToLine className="h-4 w-4 text-emerald-300" /> Deposit Funds
      </h3>

      {gwLoading && (
        <div className="mb-3 flex items-center gap-2 rounded-xl border border-white/5 bg-white/[0.02] p-3 text-xs text-slate-400">
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
          Loading platform payment details…
        </div>
      )}

      {!gwLoading && !hasAnyRail && (
        <div className="mb-3 rounded-xl border border-amber-400/25 bg-amber-500/10 p-3 text-xs text-amber-200">
          The admin hasn't configured any payment rails yet. Please use the
          chat below to request deposit instructions.
        </div>
      )}

      {!gwLoading && hasAnyRail && (
        <div className="mb-4 space-y-2">
          {railList.length > 0 ? (
            <div className="grid gap-2 sm:grid-cols-2">
              {railList.map((r) => (
                <GatewayField
                  key={r.id || r.label}
                  label={r.label || "Detail"}
                  value={r.value}
                  onCopy={copy}
                />
              ))}
            </div>
          ) : (
            <div className="grid gap-2 sm:grid-cols-2">
              <GatewayField
                label="EasyPaisa"
                value={gateway.easyPaisaNumber}
                onCopy={copy}
              />
              <GatewayField
                label="JazzCash"
                value={gateway.jazzCashNumber}
                onCopy={copy}
              />
              <GatewayField
                label="USDT · TRC20"
                value={gateway.usdtTrc20Address}
                onCopy={copy}
              />
              <GatewayField
                label="USDT · ERC20"
                value={gateway.usdtErc20Address}
                onCopy={copy}
              />
            </div>
          )}

          {uploadList.length > 0 && (
            <div className="grid gap-2 sm:grid-cols-2">
              {uploadList.map((u) => (
                <div
                  key={u.id}
                  className="rounded-xl border border-white/5 bg-white/[0.03] p-2"
                >
                  <div className="mb-1 text-[10px] font-semibold uppercase tracking-widest text-emerald-300">
                    {u.fileName || "Attachment"}
                  </div>
                  {String(u.mimeType || "").startsWith("image/") &&
                  u.dataUrl ? (
                    <a href={u.dataUrl} target="_blank" rel="noreferrer">
                      <img
                        src={u.dataUrl}
                        alt={u.fileName || "upload"}
                        className="max-h-40 w-full rounded-lg object-contain"
                      />
                    </a>
                  ) : u.dataUrl ? (
                    <a
                      href={u.dataUrl}
                      download={u.fileName || "file"}
                      className="text-xs text-cyan-300 underline"
                    >
                      Download {u.fileName || "file"}
                    </a>
                  ) : null}
                </div>
              ))}
            </div>
          )}

          {gateway.instructions && (
            <div className="rounded-xl border border-white/5 bg-white/[0.02] p-3 text-[11px] text-slate-300 whitespace-pre-wrap">
              {gateway.instructions}
            </div>
          )}
        </div>
      )}

      {/* Premium sub-text banner — nudges user to chat with admin */}
      <div className="mb-4 flex items-start gap-2 rounded-xl border border-indigo-400/25 bg-gradient-to-r from-indigo-500/10 to-emerald-400/10 p-3 text-[11px] text-indigo-100">
        <MessageCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-300" />
        <span>
          After transferring funds, please use the live chat widget below to
          instantly notify the administrator with your transaction receipt.
        </span>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="mb-1 block text-[10px] font-semibold uppercase tracking-widest text-slate-500">
              Credit To
            </label>
            <select
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
              className="w-full appearance-none rounded-xl border border-white/5 bg-white/[0.02] px-3 py-2 text-sm text-slate-100 outline-none"
            >
              {["USDT", "BTC", "ETH", "SOL"].map((s) => (
                <option key={s} value={s} className="bg-slate-900">
                  {s}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-[10px] font-semibold uppercase tracking-widest text-slate-500">
              Amount deposited
            </label>
            <input
              type="number"
              step="any"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full rounded-xl border border-white/5 bg-white/[0.02] px-3 py-2 text-sm text-slate-100 outline-none placeholder:text-slate-600"
            />
          </div>
        </div>

        <div>
          <label className="mb-1 block text-[10px] font-semibold uppercase tracking-widest text-slate-500">
            Reference / Tx Hash (optional)
          </label>
          <input
            value={txHash}
            onChange={(e) => setTxHash(e.target.value)}
            placeholder="Transfer reference or blockchain hash"
            className="w-full rounded-xl border border-white/5 bg-white/[0.02] px-3 py-2 text-sm font-mono text-slate-100 outline-none placeholder:text-slate-600"
          />
        </div>

        <motion.button
          type="submit"
          disabled={submitting || !parseFloat(amount)}
          whileHover={!submitting ? { scale: 1.01 } : undefined}
          whileTap={!submitting ? { scale: 0.99 } : undefined}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-400 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-emerald-500/25 disabled:opacity-60"
        >
          {submitting ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" /> Submitting…
            </>
          ) : (
            <>
              <Send className="h-4 w-4" /> Submit Deposit Request
            </>
          )}
        </motion.button>
      </form>
    </div>
  );
};

// ---------------------------------------------------------------------------
// WithdrawPanel
// ---------------------------------------------------------------------------
const WithdrawPanel = ({ wallet, user, toast, onWalletUpdate }) => {
  const [symbol, setSymbol] = useState("USDT");
  const [network, setNetwork] = useState("TRC20");
  const [address, setAddress] = useState(user?.trc20Address || "");
  const [amount, setAmount] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (user?.trc20Address && network === "TRC20") {
      setAddress(user.trc20Address);
    }
  }, [user?.trc20Address, network]);

  const available = wallet?.[symbol] || 0;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (submitting || !parseFloat(amount) || !address.trim()) return;
    setSubmitting(true);
    try {
      const res = await WalletAPI.withdrawRequest({
        symbol,
        amount: parseFloat(amount),
        address: address.trim(),
        network,
      });
      toast("success", res.message || "Withdrawal Pending Approval.");
      if (res.wallet) onWalletUpdate?.(res.wallet);
      setAmount("");
    } catch (err) {
      toast("error", err?.message || "Withdrawal failed.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="rounded-2xl border border-white/5 bg-slate-900/60 p-5 backdrop-blur-sm">
      <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold tracking-tight">
        <ArrowUpFromLine className="h-4 w-4 text-indigo-300" /> Withdrawal
      </h3>
      <p className="mb-3 text-[11px] text-slate-500">
        Request any amount up to your available balance. Funds are held as
        Pending Approval until admin reviews.
      </p>

      <div className="mb-3 grid grid-cols-2 gap-2">
        <div>
          <label className="mb-1 block text-[10px] font-semibold uppercase tracking-widest text-slate-500">
            Asset
          </label>
          <select
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
            className="w-full appearance-none rounded-xl border border-white/5 bg-white/[0.02] px-3 py-2 text-sm text-slate-100 outline-none"
          >
            {["USDT", "BTC", "ETH", "SOL"].map((s) => (
              <option key={s} value={s} className="bg-slate-900">
                {s}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="mb-1 block text-[10px] font-semibold uppercase tracking-widest text-slate-500">
            Network
          </label>
          <select
            value={network}
            onChange={(e) => setNetwork(e.target.value)}
            className="w-full appearance-none rounded-xl border border-white/5 bg-white/[0.02] px-3 py-2 text-sm text-slate-100 outline-none"
          >
            {["TRC20", "ERC20", "BEP20"].map((n) => (
              <option key={n} value={n} className="bg-slate-900">
                {n}
              </option>
            ))}
          </select>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <label className="mb-1 block text-[10px] font-semibold uppercase tracking-widest text-slate-500">
            Destination address
          </label>
          <input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Paste destination wallet address"
            className="w-full rounded-xl border border-white/5 bg-white/[0.02] px-3 py-2 text-sm font-mono text-slate-100 outline-none placeholder:text-slate-600"
          />
        </div>
        <div>
          <label className="mb-1 flex items-center justify-between text-[10px] font-semibold uppercase tracking-widest text-slate-500">
            <span>Amount</span>
            <span>
              Available: {fmt(available, 4)} {symbol}
            </span>
          </label>
          <input
            type="number"
            step="any"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
            className="w-full rounded-xl border border-white/5 bg-white/[0.02] px-3 py-2 text-sm text-slate-100 outline-none placeholder:text-slate-600"
          />
        </div>
        <motion.button
          type="submit"
          disabled={submitting || !parseFloat(amount) || !address.trim()}
          whileHover={!submitting ? { scale: 1.01 } : undefined}
          whileTap={!submitting ? { scale: 0.99 } : undefined}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 to-indigo-400 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 disabled:opacity-60"
        >
          {submitting ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" /> Submitting…
            </>
          ) : (
            <>
              <Send className="h-4 w-4" /> Submit Withdrawal Request
            </>
          )}
        </motion.button>
      </form>
    </div>
  );
};

// ---------------------------------------------------------------------------
// TransactionList — for Activity tab (from backend)
// ---------------------------------------------------------------------------
const TxStatus = ({ status, kind }) => {
  const map = {
    pending: "bg-amber-500/15 text-amber-300 border-amber-400/25",
    approved: "bg-emerald-500/15 text-emerald-300 border-emerald-400/25",
    completed: "bg-emerald-500/15 text-emerald-300 border-emerald-400/25",
    rejected: "bg-rose-500/15 text-rose-300 border-rose-400/25",
  };
  let label = status;
  if (status === "pending" && kind === "deposit") {
    label = "Pending Verification";
  } else if (status === "pending" && kind === "withdrawal") {
    label = "Pending Approval";
  } else if (status === "approved") {
    label = "Approved";
  } else if (status === "rejected") {
    label = "Declined";
  }
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${
        map[status] || map.pending
      }`}
    >
      {label}
    </span>
  );
};

const TransactionsList = ({ transactions, loading, onRefresh }) => (
  <div className="overflow-hidden rounded-2xl border border-white/5 bg-slate-900/60 backdrop-blur-sm">
    <div className="flex items-center justify-between border-b border-white/5 px-5 py-3">
      <h3 className="flex items-center gap-2 text-sm font-semibold">
        <History className="h-4 w-4 text-slate-400" /> All Transactions
      </h3>
      <button
        onClick={onRefresh}
        disabled={loading}
        className="flex items-center gap-1 rounded-lg border border-white/5 bg-white/[0.02] px-2 py-1 text-[10px] text-slate-300 hover:bg-white/[0.05] disabled:opacity-50"
      >
        {loading ? (
          <Loader2 className="h-3 w-3 animate-spin" />
        ) : (
          <RefreshCw className="h-3 w-3" />
        )}
        Refresh
      </button>
    </div>
    <ul className="divide-y divide-white/5">
      <AnimatePresence initial={false}>
        {transactions.map((t) => (
          <motion.li
            key={t._id}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, x: -8 }}
            layout
            className="grid grid-cols-12 items-center gap-3 px-5 py-3 text-sm"
          >
            <div className="col-span-3 flex items-center gap-3">
              <div
                className={`grid h-8 w-8 place-items-center rounded-lg ${
                  t.kind === "trade"
                    ? "bg-indigo-500/15 text-indigo-300"
                    : t.kind === "deposit"
                    ? "bg-emerald-500/15 text-emerald-300"
                    : "bg-rose-500/15 text-rose-300"
                }`}
              >
                {t.kind === "deposit" ? (
                  <ArrowDownToLine className="h-4 w-4" />
                ) : t.kind === "withdrawal" ? (
                  <ArrowUpFromLine className="h-4 w-4" />
                ) : t.side === "buy" ? (
                  <ArrowUpRight className="h-4 w-4" />
                ) : (
                  <ArrowDownRight className="h-4 w-4" />
                )}
              </div>
              <div>
                <div className="text-xs font-semibold capitalize">
                  {t.kind}
                  {t.side ? ` · ${t.side}` : ""}
                </div>
                <div className="text-[10px] text-slate-500">
                  {new Date(t.createdAt).toLocaleString()}
                </div>
              </div>
            </div>
            <div className="col-span-2 text-slate-300">{t.symbol}</div>
            <div className="col-span-2 tabular-nums text-slate-200">
              {fmt(t.amount, 6)}
            </div>
            <div className="col-span-2 text-xs text-slate-500">
              {t.network || "—"}
            </div>
            <div className="col-span-3 text-right">
              <TxStatus status={t.status} kind={t.kind} />
            </div>
          </motion.li>
        ))}
      </AnimatePresence>
      {!loading && transactions.length === 0 && (
        <li className="px-5 py-10 text-center text-xs text-slate-500">
          No transactions yet.
        </li>
      )}
    </ul>
  </div>
);

// ---------------------------------------------------------------------------
// Main Dashboard — mobile-first Seconds Trading shell
// ---------------------------------------------------------------------------
export default function Dashboard({ user, onLogout, onOpenAdmin }) {
  const [page, setPage] = useState("home");
  const [mode, setMode] = useState("trade");
  const [tab, setTab] = useState("home"); // legacy bottom-nav compat
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [kycOpen, setKycOpen] = useState(false);
  const [me, setMe] = useState(user);
  const [globalTradingEnabled, setGlobalTradingEnabled] = useState(true);
  const [liveEarnings, setLiveEarnings] = useState(0);
  const [transactions, setTransactions] = useState([]);
  const [txLoading, setTxLoading] = useState(false);
  const [toast, setToast] = useState({ kind: null, message: "" });
  const [chatOpenSignal, setChatOpenSignal] = useState(0);
  const [chatHint, setChatHint] = useState(null);
  const [assetsView, setAssetsView] = useState("overview");
  const [tradeIntent, setTradeIntent] = useState(null); // { asset, assetType, pair }

  const goPage = (p) => {
    const key = p === "delivery" || p === "spot" || p === "perpetual" ? "trade" : p;
    setPage(key);
    if (key === "assets") setAssetsView("overview");
    if (key === "deposit") setAssetsView("deposit");
    if (key === "withdraw") setAssetsView("withdraw");
    if (key === "trade") setTab("trading");
    else if (key === "assets" || key === "deposit" || key === "withdraw") setTab("wallet");
    else if (key === "account") setTab("settings");
    else if (key === "home") setTab("home");
    else if (key === "market") setTab("trading");
  };

  const say = useCallback((kind, message) => {
    setToast({ kind, message });
    setTimeout(() => setToast({ kind: null, message: "" }), 2600);
  }, []);

  const openTradeDesk = useCallback(
    (payload = {}) => {
      const asset = String(payload.asset || "BTC").toUpperCase();
      const assetType =
        payload.assetType === "stock"
          ? "stock"
          : payload.assetType === "forex"
            ? "forex"
            : "crypto";
      const quote = String(payload.quote || "").toUpperCase() || undefined;
      setTradeIntent({
        asset,
        assetType,
        quote,
        pair: payload.pair || `${asset}/${quote || "USDT"}`,
        category: payload.category || "Crypto",
        at: Date.now(),
      });
      setMode("trade");
      setPage("trade");
      setTab("trading");
      // Also broadcast for any already-mounted listeners
      setTimeout(() => {
        window.dispatchEvent(
          new CustomEvent("nexus:select-asset", {
            detail: { asset, assetType, quote },
          })
        );
      }, 80);
      const label = payload.pair || `${asset}/${quote || "USDT"}`;
      say("success", `Opening trade desk · ${label}`);
    },
    [say]
  );

  const openLiveChat = useCallback((hint = "deposit") => {
    setChatHint(hint || "deposit");
    setChatOpenSignal((n) => n + 1);
  }, []);

  const openDepositSection = useCallback(() => {
    setAssetsView("deposit");
    setPage("deposit");
    setTab("wallet");
    openLiveChat("deposit");
  }, [openLiveChat]);

  const openWithdrawSection = useCallback(() => {
    setAssetsView("withdraw");
    setPage("withdraw");
    setTab("wallet");
    openLiveChat("withdraw");
  }, [openLiveChat]);

  useEffect(() => {
    const onOpenChat = (e) => {
      openLiveChat(e?.detail?.hint || "deposit");
    };
    window.addEventListener("nexus:open-chat", onOpenChat);
    return () => window.removeEventListener("nexus:open-chat", onOpenChat);
  }, [openLiveChat]);

  useEffect(() => {
    const onCert = () => goPage("certificate");
    window.addEventListener("nexus:open-certificate", onCert);
    return () => window.removeEventListener("nexus:open-certificate", onCert);
  }, []);

  const wallet = useMemo(() => {
    const w = me?.wallet;
    if (!w) return {};
    if (w instanceof Map) return Object.fromEntries(w);
    return { ...w };
  }, [me]);

  const walletUsdt = Number(wallet.USDT || 0);
  const tradingSuspended =
    globalTradingEnabled === false || me?.tradingAllowed === false;

  const loadTx = async () => {
    setTxLoading(true);
    try {
      const res = await WalletAPI.transactions();
      setTransactions(res.transactions || []);
    } catch {
      /* ignore */
    } finally {
      setTxLoading(false);
    }
  };

  const loadLiveEarnings = async () => {
    try {
      const res = await SecondsTradeAPI.history();
      let total = 0;
      for (const t of res.trades || []) {
        const s = String(t.status || "").toLowerCase();
        if (s === "won" || s === "win") {
          total += Math.max(0, Number(t.payout || 0) - Number(t.stake || 0));
        }
      }
      setLiveEarnings(total);
    } catch {
      /* ignore */
    }
  };

  useEffect(() => {
    if (tab === "history" || tab === "home") loadTx();
    if (tab === "home" || tab === "trading") loadLiveEarnings();
  }, [tab]);

  // Keep Trading Wallet / permissions in sync when admin changes access
  useEffect(() => {
    let cancelled = false;
    const refreshMe = async () => {
      try {
        const res = await AuthAPI.me();
        if (!cancelled && res?.user) {
          setMe((prev) => ({
            ...prev,
            ...res.user,
            wallet: res.user.wallet ?? prev?.wallet,
          }));
          if (typeof res.globalTradingEnabled === "boolean") {
            setGlobalTradingEnabled(res.globalTradingEnabled);
          }
        }
      } catch {
        /* ignore transient */
      }
    };
    refreshMe();
    loadLiveEarnings();
    getSocket();
    const id = setInterval(refreshMe, 2500);
    const eId = setInterval(loadLiveEarnings, 5000);
    const offWallet = onSocketEvent("wallet:update", (payload) => {
      if (!payload?.wallet || cancelled) return;
      setMe((prev) => {
        const myId = prev?._id || prev?.id;
        if (
          payload.userId &&
          myId &&
          String(payload.userId) !== String(myId)
        ) {
          return prev;
        }
        return { ...prev, wallet: payload.wallet };
      });
      if (payload.reason === "deposit_approved") {
        say(
          "success",
          `Deposit approved — Trading Wallet updated${
            payload.amount != null
              ? ` (+$${Number(payload.amount).toFixed(2)} ${payload.symbol || "USDT"})`
              : ""
          }.`
        );
        loadTx();
      } else if (
        payload.reason === "deposit_rejected" ||
        payload.status === "rejected"
      ) {
        say("error", "Deposit marked REJECTED — balance unchanged.");
        loadTx();
      }
    });
    return () => {
      cancelled = true;
      clearInterval(id);
      clearInterval(eId);
      offWallet();
      disconnectSocket();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleLogout = async () => {
    try {
      await AuthAPI.logout().catch(() => {});
    } finally {
      clearToken();
      onLogout?.();
    }
  };

  const handleUserUpdate = (u) => {
    if (!u) return;
    setMe((prev) => ({
      ...prev,
      ...u,
      wallet: u.wallet || prev?.wallet,
    }));
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen"
    >
      <Toast
        kind={toast.kind}
        message={toast.message}
        onClose={() => setToast({ kind: null, message: "" })}
      />

      <PlatformShell
        user={me}
        page={page}
        onPageChange={goPage}
        walletUsdt={walletUsdt}
        onLogout={handleLogout}
        onOpenAccount={() => goPage("account")}
        onOpenKyc={() => setKycOpen(true)}
        onOpenDeposit={openDepositSection}
        onOpenChat={(hint) => {
          const h = typeof hint === "string" ? hint : "info";
          openLiveChat(h === "deposit" ? "deposit" : h);
        }}
        onNotificationSelect={(n) => {
          if (n?.type === "chat" || n?.meta?.kind === "chat") {
            openLiveChat("service");
          }
        }}
      >
        {me?.kyc?.status !== "approved" && page !== "assets" && (
          <motion.button
            type="button"
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={() => setKycOpen(true)}
            className="mb-4 flex w-full items-start gap-2.5 rounded-xl border border-amber-400/30 bg-amber-500/10 px-3.5 py-3 text-left"
          >
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
            <div className="min-w-0 flex-1">
              <div className="text-xs font-semibold text-amber-100">
                {me?.kyc?.status === "pending"
                  ? "Identity verification under review"
                  : "Unverified account — trading limits apply"}
              </div>
              <div className="mt-0.5 text-[11px] text-amber-200/70">
                Complete Identity Verification — choose ID Card or Driving License.
              </div>
            </div>
            <span className="shrink-0 text-[10px] font-bold uppercase tracking-wider text-amber-300">
              {me?.kyc?.status === "pending" ? "Pending" : "Verify"}
            </span>
          </motion.button>
        )}

        <AnimatePresence mode="wait">
          {page === "home" && (
            <motion.div key="home" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <HomeLanding user={me} walletUsdt={walletUsdt} liveEarnings={liveEarnings} onStartTrading={() => goPage("trade")} />
              {isStaffRole(me?.role) && (
                <button type="button" onClick={onOpenAdmin} className="mt-4 w-full rounded-xl border border-indigo-400/30 bg-indigo-500/10 py-3 text-sm font-semibold text-indigo-200">
                  Open Admin Console
                </button>
              )}
            </motion.div>
          )}
          {page === "market" && (
            <MarketPage
              key="market"
              onToast={say}
              onNavigate={goPage}
              onTradePair={openTradeDesk}
              user={me}
            />
          )}
          {page === "deposit" && (
            <div key="deposit" className="mx-auto max-w-2xl">
              <DepositSection toast={say} onOpenLiveChat={() => openLiveChat("deposit")} />
            </div>
          )}
          {page === "withdraw" && (
            <div key="withdraw" className="mx-auto max-w-2xl">
              <WithdrawSection
                wallet={wallet}
                user={me}
                toast={say}
                onWalletUpdate={handleUserUpdate}
                onOpenLiveChat={() => openLiveChat("withdraw")}
              />
            </div>
          )}
          {page === "trade" && (
            <motion.div
              key={`trade-${tradeIntent?.at || "desk"}`}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mx-auto grid max-w-[1400px] gap-4 xl:grid-cols-[minmax(0,1.4fr)_minmax(280px,0.7fr)]"
            >
              <div className="min-w-0 space-y-4">
                <SecondsTrading
                  walletUsdt={walletUsdt}
                  onWalletUpdate={handleUserUpdate}
                  onToast={say}
                  tradingSuspended={tradingSuspended}
                  initialAsset={tradeIntent?.asset || "BTC"}
                  initialAssetType={tradeIntent?.assetType || "crypto"}
                  initialQuote={tradeIntent?.quote || "USDT"}
                />
              </div>
              <div className="space-y-4">
                <CryptoWatchlist />
                <MarketActivity />
              </div>
            </motion.div>
          )}
          {page === "aibot" && (
            <AiBotTradingPage
              key="aibot"
              user={me}
              onToast={say}
              onWalletUpdate={handleUserUpdate}
            />
          )}
          {page === "loan" && (
            <LoanPage
              key="loan"
              onToast={say}
              user={me}
              onOpenLiveChat={() => openLiveChat("loan")}
            />
          )}
          {page === "referral" && (
            <motion.div
              key="referral"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mx-auto max-w-5xl"
            >
              <ReferralSection user={me} onToast={say} />
            </motion.div>
          )}
          {page === "assets" && (
            <AssetsHubPage
              key={`assets-${assetsView}`}
              user={me}
              onToast={say}
              onOpenKyc={() => setKycOpen(true)}
              onOpenDeposit={openDepositSection}
              onOpenLiveChat={(hint) => openLiveChat(hint || "deposit")}
              onOpenWithdraw={openWithdrawSection}
              onWalletUpdate={handleUserUpdate}
              initialView={assetsView}
            />
          )}
          {page === "account" && (
            <motion.div key="account" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mx-auto max-w-2xl space-y-4">
              <ProfileSetup user={me} toast={say} onSaved={(u) => handleUserUpdate(u)} onLogout={handleLogout} />
              <button type="button" onClick={() => setKycOpen(true)} className="flex w-full items-center justify-center gap-2 rounded-xl border border-emerald-400/25 bg-emerald-500/10 py-3 text-sm font-semibold text-emerald-200">
                <ShieldCheck className="h-4 w-4" /> Identity Verification (ID Card / License)
              </button>
            </motion.div>
          )}
          {page === "about" && (
            <motion.div key="about" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mx-auto max-w-4xl">
              <AboutPage
                onCta={() => goPage("trade")}
                onSupport={() => openLiveChat("info")}
                ctaLabel="Open Trade desk"
              />
            </motion.div>
          )}
          {page === "contact" && (
            <motion.div key="contact" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mx-auto max-w-3xl">
              <ContactPage onSupport={() => openLiveChat("info")} ctaLabel="Open Live Chat" />
            </motion.div>
          )}
          {page === "certificate" && (
            <motion.div key="certificate" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mx-auto max-w-3xl">
              <CertificatePage
                onBack={() => goPage("home")}
                onContact={() => goPage("contact")}
              />
            </motion.div>
          )}
          {page === "vip" && (
            <motion.div key="vip" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mx-auto max-w-5xl">
              <VipPage
                user={me}
                onCta={() => goPage("trade")}
                onSupport={() => openLiveChat("vip")}
                onReferral={() => goPage("referral")}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </PlatformShell>

      <KYCModule
        user={me}
        open={kycOpen}
        onClose={() => setKycOpen(false)}
        onUpdated={(u) => setMe(u)}
      />

      {/* Single floating Live Chat — Deposit CTA opens it */}
      {!isStaffRole(me?.role) && (
        <LiveChatWidget
          user={me}
          contextHint={chatHint}
          openSignal={chatOpenSignal}
          onToast={say}
          onWalletUpdate={(w) =>
            setMe((prev) => ({ ...prev, wallet: w || prev?.wallet }))
          }
          onDepositSubmitted={() => {
            loadTx();
            say(
              "success",
              "Deposit Pending Verification — awaiting admin approval."
            );
          }}
        />
      )}
    </motion.div>
  );
}
